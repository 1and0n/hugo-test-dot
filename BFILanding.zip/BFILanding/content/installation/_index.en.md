---
title: "Installations"
date: 2018-12-29T11:02:05+06:00
icon: "ti-panel"
description: "Welcome to installation"
type : "pages"
---
