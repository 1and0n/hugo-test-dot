---
title: "Requirments"
date: 2018-12-29T11:02:05+06:00
type: "post"
weight: 1
---


Thanks to the simplicity of Hugo, this page is as empty as this theme needs requirements.

Just download latest version of [Hugo binary (> 0.53)](https://gohugo.io/getting-started/installing/) for your OS (Windows, Linux, Mac) : it's that simple.

![image example](../../../../images/hugo.jpg "image")