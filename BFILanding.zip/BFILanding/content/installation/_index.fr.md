---
title: "Installation"
date: 2018-12-29T11:02:05+06:00
icon: "ti-panel"
description: "Lorem ipsum dolor sit amet ipsum dolor sit amet ipsum dolor sit amet"
type : "pages"
---