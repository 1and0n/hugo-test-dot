---
title: "quickstart"
date: 2018-12-28T11:02:05+06:00
icon: "ti-package"
description: "Learn how to quickstart"
type : "pages"
---


Note that some of these parameters are explained in details in other sections of this documentation.
